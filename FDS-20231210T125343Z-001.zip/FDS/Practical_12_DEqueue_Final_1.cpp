#include<iostream>
using namespace std;
#define size 5
class dqueue{
      int q[size];
      int f,r;
public :
      dqueue(){
            f=r=-1;
            q[-1]=NULL;
      }

      void display(){
            for(int i=f ; i<=r ; i++){
                  cout<<"\n"<<q[i];
            }
      }
      void insert_end(int data){
            if(r==size-1){
                  cout<<"\nNotpossibel";
            }
            else{
            if(f==-1 && r==-1){
                              f=r=0;
                              q[r]=data;
                        }
                        else{
                              r=r+1;
                              q[r]=data;
                        }

                        display();
                  }}
      void delete_end()
      {
              if(f==-1)
              {
                  cout<<"deletion is not possible::dequeue is empty";
                  return;
              }
              else
              {
                  cout<<"the deleted element is"<<q[r];
                  if(f==r)
                  {
                      f=r=-1;
                  }
                  else
                      r=r-1;
              }
              display();
      }
      void delete_front(){
            if(f==-1)
                    {
                        cout<<"deletion is not possible::dequeue is empty";
                        return;
                    }
                    else
                    {
                        cout<<"the deleted element is"<<q[f];
                        if(f==r)
                        {
                            f=r=-1;
                            return;
                        }
                        else
                            f=f+1;
                    }
            display();

      }
      void insert_begin(int data){

            if(f==-1 && r==-1){
                  f=r=0;
                  q[f]=data;
            }

            else if(f!=0){
                  f=f-1;
                  q[f]=data;
            }
            else
                  cout<<"\nNot possible ";

            display();
      }
};
int main(){
      int ch;
      int data;
      dqueue q;
      do{
            cout<<"\n1.Add at begin \n2.Add at end \n3.Delete front \n4.Delete end\n5.Exit";
            cin>>ch;
            switch(ch){
            case 1 : cout<<"\nEnter data : ";
                        cin>>data;
                        q.insert_begin(data);
                        break;
            case 2 : cout<<"\nEnter data : ";
                        cin>>data;
                        q.insert_end(data);
                        break;
            case 3 :q.delete_front();break;
            case 4 :q.delete_end();break;
            }
      }while(ch!=5);
      return 0;
}
